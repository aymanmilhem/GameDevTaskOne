﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracricalTask1
{
    class Program
    {
        //enum contains player types
        enum PlayerType{
            TeamMember,
            Enemy,
            Civilian
        };

        //Player Class defines the players' properties and methods
        class Player
        {
            public string name;
            public PlayerType type;
            public int health, weaponEffect, gameCredit;

            //Constructor
            public Player(string name, PlayerType type, int health, int weaponEffect, int gameCredit)
            {
                this.name = name;
                this.type = type;
                this.health = health;
                this.weaponEffect = weaponEffect;
                this.gameCredit = gameCredit;
            }

            //Construct a string record of this object and print it to console 
            public void Print()
            {
                Console.WriteLine(String.Format("{0}, Type: {1}, Health: {2}, WeaponEffect: {3}, GameCredit: {4}",
                    this.name, this.type, this.health, this.weaponEffect, this.gameCredit));
            }

            //Spend one GameCredit with every call, and increment credits accordingly
            //Output results to console for monitoring
            public void Spend()
            {
                if (this.type == PlayerType.TeamMember || this.type == PlayerType.Enemy)
                {
                    this.gameCredit--;
                    this.weaponEffect++;
                    this.Print();
                }
                else
                {
                    this.gameCredit--;
                    this.health += 5;
                    this.Print();
                }
            }

            //Spend all credits until no credits left for this object.
            public void SpendAllGameCredits()
            {
                Console.WriteLine(String.Format("Updating {0}'s credits: ", this.name));
                Console.WriteLine("======================================");
                while (this.gameCredit > 0)
                {
                    this.Spend();
                }
                Console.WriteLine();
            }

        }

        static void Main(string[] args)
        {
            //Instantiate Player objects for all four players
            Player playerOne = new Player("DeanKeaton", PlayerType.TeamMember, 15, 4, 5);
            Player playerTwo = new Player("KeizerSoze", PlayerType.Enemy, 100, 2, 15);
            Player playerThree = new Player("ToddHockney", PlayerType.TeamMember, 25, 2, 10);
            Player playerFour = new Player("EdieFinneran", PlayerType.Civilian, 90, 0, 30);

            //Output the before state to console
            Console.WriteLine("**** Welcome to FPS Extreme ****");
            Console.WriteLine("The Characters in this game are: ");
            playerOne.Print();
            playerTwo.Print();
            playerThree.Print();
            playerFour.Print();
            Console.WriteLine();

            //Spending all credits from all players
            playerOne.SpendAllGameCredits();
            playerTwo.SpendAllGameCredits();
            playerThree.SpendAllGameCredits();
            playerFour.SpendAllGameCredits();

            //Output the after state of players' credits.
            Console.WriteLine("Players' Current Credit Status After Spending: ");
            Console.WriteLine("===============================================");
            playerOne.Print();
            playerTwo.Print();
            playerThree.Print();
            playerFour.Print();

            //wait for the "enter" key to be pressed
            Console.ReadLine();
        }
    }
}
